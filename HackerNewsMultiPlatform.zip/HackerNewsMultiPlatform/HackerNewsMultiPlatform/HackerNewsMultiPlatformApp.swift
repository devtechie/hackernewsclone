///**
/**

HackerNewsMultiPlatform
CREATED BY:  DEVTECHIE INTERACTIVE, INC. ON 8/29/20
COPYRIGHT (C) DEVTECHIE, DEVTECHIE INTERACTIVE, INC

*/

import SwiftUI

@main
struct HackerNewsMultiPlatformApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
