///**
/**

HackerNewsMultiPlatform
CREATED BY:  DEVTECHIE INTERACTIVE, INC. ON 8/29/20
COPYRIGHT (C) DEVTECHIE, DEVTECHIE INTERACTIVE, INC

*/

import Foundation

struct Results: Decodable {
    let hits: [Post]
}

struct Post: Decodable, Identifiable {
    var id: String {
        return objectID
    }
    let objectID: String
    let title: String
    let url: String?
}
