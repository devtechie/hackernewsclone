///**
/**
 
 HackerNewsMultiPlatform
 CREATED BY:  DEVTECHIE INTERACTIVE, INC. ON 8/29/20
 COPYRIGHT (C) DEVTECHIE, DEVTECHIE INTERACTIVE, INC
 
 */

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var manager = NetworkManager()
    
    var body: some View {
        NavigationView {
            List(manager.posts) { post in
                NavigationLink(
                    destination: DetailView(url: post.url)) {
                    HStack {
                        Text(post.title)
                    }
                }
            }
            .navigationTitle("Hacker News Clone")
        }
        .onAppear {
            self.manager.getNews()
        }
    }
}
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
